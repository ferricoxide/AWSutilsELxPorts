HIGH_NETWORK_PERFORMANCE = ["100 Gigabit",
                            "50 Gigabit",
                            "25 Gigabit",
                            "20 Gigabit",
                            "10 Gigabit"]
