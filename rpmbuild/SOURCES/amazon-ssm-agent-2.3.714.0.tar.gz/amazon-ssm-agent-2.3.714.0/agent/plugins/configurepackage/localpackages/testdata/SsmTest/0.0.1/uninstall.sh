cp test_installed.txt test_uninstalled.txt
exit 0
