cp test.txt test_installed.txt
exit 0
